"""Caso de uso: calcular todo lo que muestra el dashboard a partir de la base de datos."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from sqlalchemy.orm import Session, sessionmaker

from core import metrics
from core.account_metrics import expense_breakdown
from core.budget import BudgetLine, budget_lines
from core.metrics import AllocationSlice, FlowOptions, MonthlyFlow, WealthPoint
from core.forecast import MonthForecast, forecast_month_end
from core.recurring import Recurring, detect_recurring
from core.suggestions import RuleSuggestion, suggest_rules, uncategorized
from data.database import session_scope
from data.tracker import tracker_for
from core.goals import Goal
from data.repositories import get_budgets, get_recurring_marks, last_import_date, list_goals
from etl.reconcile import reconcile_portfolio
from services.mappers import cached_transactions, load_operations, load_prices, load_snapshots

FLOW_MONTHS = 12
UPCOMING_DAYS = 35       # pagos recurrentes que se esperan en este plazo desde el ultimo dia con datos


@dataclass(slots=True)
class DashboardData:
    has_data: bool = False
    cash: Decimal | None = None
    portfolio_value: Decimal = Decimal(0)
    net_worth: Decimal = Decimal(0)
    simple_return: Decimal | None = None
    xirr: float | None = None
    twr: float | None = None
    report_month: date | None = None
    month_income: Decimal = Decimal(0)
    month_expenses: Decimal = Decimal(0)
    month_savings_rate: Decimal | None = None
    allocation: list[AllocationSlice] = field(default_factory=list)
    flows: list[MonthlyFlow] = field(default_factory=list)
    wealth: list[WealthPoint] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    upcoming: list[Recurring] = field(default_factory=list)       # proximos pagos recurrentes, el mas cercano primero
    budgets: list[BudgetLine] = field(default_factory=list)       # todos los presupuestos frente al gasto del ultimo mes, del mas gastado al menos
    has_budgets: bool = False
    net_worth_change: Decimal | None = None   # frente al cierre del mes anterior (None si aun no hay dos meses de datos)
    goals: list[Goal] = field(default_factory=list)               # metas de ahorro
    last_update: date | None = None      # cuando se actualizaron los datos por ultima vez
    forecast: MonthForecast | None = None                           # lo que se espera tener en las cuentas a fin de mes
    uncategorized_count: int = 0                                    # movimientos que aun no tienen categoria
    uncategorized_total: Decimal = Decimal(0)
    suggestions: list[RuleSuggestion] = field(default_factory=list)    # comercios repetidos entre ellos: reglas de un clic
    has_transactions: bool = False
    has_operations: bool = False
    has_portfolio: bool = False


class DashboardService:
    def __init__(self, factory: sessionmaker[Session]) -> None:
        self._factory = factory
        self._tracker = tracker_for(factory.kw["bind"])

    def load(self, options: FlowOptions = FlowOptions()) -> DashboardData:
        # El resultado se reutiliza mientras no cambien los datos: volver a Inicio no vuelve a calcularlo todo.
        return self._tracker.cached(("dashboard", options), lambda: self._load(options))

    def _load(self, options: FlowOptions) -> DashboardData:
        txs = cached_transactions(self._factory)
        with session_scope(self._factory) as s:
            ops, snaps = load_operations(s), load_snapshots(s)
            prices = load_prices(s)
            budgets = get_budgets(s)
            imported = last_import_date(s)
            goals = [Goal(g.id, g.name, g.target, g.saved, g.deadline) for g in list_goals(s)]
            marks = get_recurring_marks(s)
        if not (txs or ops or snaps):
            return DashboardData()

        latest = metrics.latest_positions(snaps)
        cash = metrics.total_cash(txs)
        data = DashboardData(
            has_data=True,
            has_transactions=bool(txs),
            has_operations=bool(ops),
            has_portfolio=bool(snaps),
            has_budgets=bool(budgets),
            goals=goals,
            cash=cash,
            portfolio_value=metrics.portfolio_value(latest),
            net_worth=metrics.net_worth(cash, latest),
            simple_return=metrics.simple_return(latest),
            xirr=metrics.portfolio_xirr(ops, snaps) if ops else None,
            twr=metrics.twr(ops, snaps, prices=prices) if ops else None,
            allocation=metrics.asset_allocation(cash, latest),
            warnings=reconcile_portfolio(latest, ops) if latest else [],
        )

        # Fecha de la ultima importacion; si no hay marcas (p. ej. solo cartera), el dia mas reciente que traen los datos.
        newest = [d for d in ([t.booking_date for t in txs] + [o.trade_date for o in ops] + [p.as_of for p in snaps])]
        data.last_update = imported or (max(newest) if newest else None)

        flows = metrics.monthly_cashflow(txs, ops, options)
        data.flows = flows[-FLOW_MONTHS:]
        if txs:
            data.report_month = metrics.month_start(max(t.booking_date for t in txs))
            current = next((f for f in flows if f.month == data.report_month), None)
            if current:
                data.month_income, data.month_expenses = current.income, current.expenses
                data.month_savings_rate = current.savings_rate
            last_day = max(t.booking_date for t in txs)
            recurring = detect_recurring(txs, marks=marks)
            data.upcoming = sorted((r for r in recurring if (r.next_date - last_day).days <= UPCOMING_DAYS), key=lambda r: r.next_date)
            data.forecast = forecast_month_end(txs, options, recurring=recurring, marks=marks)
            pending = uncategorized(txs)
            data.uncategorized_count = len(pending)
            data.uncategorized_total = sum((abs(t.amount) for t in pending), Decimal(0))
            data.suggestions = suggest_rules(txs)
            data.has_budgets = bool(budgets)
            this_month = [t for t in txs if metrics.month_start(t.booking_date) == data.report_month]
            data.budgets = budget_lines(budgets, expense_breakdown(this_month, options))

        points = [t.booking_date for t in txs] + [o.trade_date for o in ops] + [p.as_of for p in snaps]
        data.wealth = metrics.wealth_evolution(txs, ops, snaps, metrics.month_ends(min(points), max(points)), prices)
        if len(data.wealth) >= 2:
            data.net_worth_change = data.wealth[-1].net_worth - data.wealth[-2].net_worth
        return data

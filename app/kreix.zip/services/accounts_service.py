"""Caso de uso de la pestana Cuentas: varias cuentas, metricas y movimientos por periodo."""
from __future__ import annotations

from dataclasses import replace, dataclass, field
from datetime import date
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from core import metrics
from core.account_metrics import AccountSummary, CategoryAmount, available_months, expense_breakdown, summarize_account
from core.budget import BudgetLine, budget_lines
from core.entities import TransactionDraft
from core.enums import AccountKind, Bank
from core.metrics import FlowOptions, MonthlyFlow
from core.periods import GLOBAL, Period, month_start, previous_month_end
from core.recurring import Recurring, detect_recurring, merchant_key
from data.database import session_scope
from data.tracker import tracker_for
from data.models import Account, Transaction
from data.repositories import get_recurring_marks, set_recurring_mark
from data.repositories import add_account, delete_account, get_budgets, list_accounts, rename_account
from services.mappers import cached_transactions


@dataclass(frozen=True, slots=True)
class AccountInfo:
    id: int
    name: str
    bank: Bank
    kind: AccountKind


@dataclass(slots=True)
class AccountsViewData:
    accounts: list[AccountInfo] = field(default_factory=list)
    selected: list[int] = field(default_factory=list)
    months: list[date] = field(default_factory=list)             # meses con movimientos, el mas reciente primero
    period: Period = GLOBAL
    summary: AccountSummary | None = None
    categories: list[CategoryAmount] = field(default_factory=list)
    balance_series: list[tuple[date, Decimal]] = field(default_factory=list)
    monthly: list[MonthlyFlow] = field(default_factory=list)
    movements: list[TransactionDraft] = field(default_factory=list)   # del periodo, el mas reciente primero
    previous: AccountSummary | None = None       # el mes anterior (solo si se mira un mes y hay datos en el)
    previous_month: date | None = None
    recurring: list[Recurring] = field(default_factory=list)          # pagos recurrentes activos
    budgets: list[BudgetLine] = field(default_factory=list)           # presupuestos frente al gasto del periodo

    @property
    def has_movements(self) -> bool:
        return bool(self.months)


class AccountsService:
    def __init__(self, factory: sessionmaker[Session]) -> None:
        self._factory = factory
        self._tracker = tracker_for(factory.kw["bind"])

    # -- gestion de cuentas ------------------------------------------------
    def accounts(self) -> list[AccountInfo]:
        with session_scope(self._factory) as s:
            return [AccountInfo(a.id, a.name, a.bank, a.kind) for a in list_accounts(s, AccountKind.CHECKING)]

    def add(self, name: str) -> AccountInfo:
        with session_scope(self._factory) as s:
            a = add_account(s, name)
            return AccountInfo(a.id, a.name, a.bank, a.kind)

    def rename(self, account_id: int, name: str) -> None:
        with session_scope(self._factory) as s:
            rename_account(s, account_id, name)

    def delete(self, account_id: int) -> None:
        with session_scope(self._factory) as s:
            delete_account(s, account_id)

    def recurring_marks(self) -> dict[str, bool]:
        with session_scope(self._factory) as s:
            return get_recurring_marks(s)

    def set_recurring(self, description: str, include: bool | None) -> bool:
        """Marca un comercio (por el concepto de uno de sus cargos) como pago recurrente (`True`), como que no lo es (`False`) o
        deja que Kreix decida (`None`). Devuelve False si el concepto no da una clave de comercio."""
        key = merchant_key(description)
        if not key:
            return False
        with session_scope(self._factory) as s:
            set_recurring_mark(s, key, include)
        return True

    def search_movements(self, text: str, limit: int = 6) -> list[TransactionDraft]:
        """Los movimientos mas recientes cuyo concepto contiene el texto (para el buscador global)."""
        like = "%" + text.replace("%", r"\%").replace("_", r"\_") + "%"
        with session_scope(self._factory) as s:
            rows = s.execute(
                select(Transaction, Account.bank).join(Account, Account.id == Transaction.account_id)
                .where(Transaction.description.like(like, escape="\\"))
                .order_by(Transaction.booking_date.desc(), Transaction.id.desc()).limit(limit))
            return [
                TransactionDraft(bank=bank, booking_date=t.booking_date, description=t.description, amount=t.amount,
                                 balance_after=t.balance_after, category=t.category, tx_hash=t.tx_hash,
                                 source_file=t.source_file or "", account_id=t.account_id, is_manual=t.category_is_manual)
                for t, bank in rows
            ]

    # -- datos de la pestana ----------------------------------------------
    def view(
        self,
        account_ids: list[int] | None = None,
        month: date | None = None,
        options: FlowOptions = FlowOptions(),
    ) -> AccountsViewData:
        """`account_ids=None` son todas las cuentas; `month=None` es el periodo global.
        El resultado se reutiliza mientras no cambien los datos (cambiar de pestana y volver es instantaneo)."""
        key = ("accounts", None if account_ids is None else tuple(account_ids), month, options)
        return self._tracker.cached(key, lambda: self._view(account_ids, month, options))

    def _view(self, account_ids: list[int] | None, month: date | None, options: FlowOptions) -> AccountsViewData:
        accounts = self.accounts()
        valid = {a.id for a in accounts}
        selected = [i for i in (account_ids if account_ids is not None else sorted(valid)) if i in valid]
        if set(selected) != valid:                  # mirando solo algunas cuentas: el traspaso a otra cuenta que no se mira si cuenta
            options = replace(options, scope=frozenset(selected))
        txs = [t for t in cached_transactions(self._factory) if t.account_id in selected]
        with session_scope(self._factory) as s:
            budgets = get_budgets(s)
            marks = get_recurring_marks(s)

        period = Period.month(month) if month else GLOBAL
        inside = [t for t in txs if period.contains(t.booking_date)]
        months = available_months(txs)
        breakdown = expense_breakdown(inside, options)
        previous = previous_month = None
        if month:
            before = month_start(previous_month_end(month))
            if before in months:
                previous_month = before
                previous = summarize_account(txs, Period.month(before), options)
        return AccountsViewData(
            accounts=accounts,
            selected=selected,
            months=months,
            period=period,
            summary=summarize_account(txs, period, options) if txs else None,
            categories=breakdown,
            balance_series=metrics.balance_series(txs, period.start, period.end),
            monthly=metrics.monthly_cashflow(txs, options=options),
            movements=metrics.order_movements(inside, newest_first=True),
            previous=previous,
            previous_month=previous_month,
            recurring=detect_recurring(txs, marks=marks),
            budgets=budget_lines(budgets, breakdown, 1 if month else max(len(months), 1)),
        )

"""Marcas de las cantidades ocultas (de ui/blur.py, sin Qt; generado por tools/build_pwa.py)."""
from __future__ import annotations

START = "⁠"


END = "⁣"


def mark(text: str) -> str:
    return f"{START}{text}{END}"


def has_mark(text: str) -> bool:
    return START in text


def split(text: str) -> tuple[str, list[tuple[int, int]]]:
    """('Gastas ⁠8.888,88 €⁣ al mes') -> (texto sin marcas, [(inicio, fin) de cada cantidad en ese texto])."""
    clean: list[str] = []
    spans: list[tuple[int, int]] = []
    begin = -1
    for ch in text:
        if ch == START:
            begin = len("".join(clean))
        elif ch == END:
            if begin >= 0:
                spans.append((begin, len("".join(clean))))
            begin = -1
        else:
            clean.append(ch)
    return "".join(clean), spans


def clean_text(text: str) -> str:
    return text.replace(START, "").replace(END, "")
